import {useQuery} from "@tanstack/react-query";
import {getProductColor} from '../../../shared/api/api'


function useProductColor(productID, colorID) {
    const { isPending, error, data } = useQuery({
        queryKey: ['product', productID, 'color', colorID],
        queryFn: () =>
            getProductColor(productID, colorID),
    })
}
