import type {Color} from '../../color/model'

type Product = {
    id: number,
    name: string,
    categoryId: number,
    brand: string,
    colors: Array<Color>
}
