import {useQuery} from "@tanstack/react-query";
import {getProduct} from '../../../shared/api/api'

function useProduct(productID) {
    const { isPending, error, data } = useQuery({
        queryKey: ['product', productID],
        queryFn: () =>
            getProduct(productID),
    })
}
