import {useQuery} from "@tanstack/react-query";
import {getProducts} from '../../../shared/api/api'

function useProducts() {
    const { isPending, error, data } = useQuery({
        queryKey: ['products'],
        queryFn: () =>
            getProducts(),
    })
}
