import {useQuery} from "@tanstack/react-query";
import {getSizes} from '../../../shared/api/api'

function useSizes() {
    const { isPending, error, data } = useQuery({
        queryKey: ['sizes'],
        queryFn: () =>
            getSizes(),
    })
}
