import {useQuery} from "@tanstack/react-query";
import {getSize} from '../../../shared/api/api'

function useSize(sizeID) {
    const { isPending, error, data } = useQuery({
        queryKey: ['size', sizeID],
        queryFn: () =>
            getSize(sizeID),
    })
}
